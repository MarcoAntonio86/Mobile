package devandroid.marcoantonio.calculadorasimples.Model;

public class Calculadora {
}

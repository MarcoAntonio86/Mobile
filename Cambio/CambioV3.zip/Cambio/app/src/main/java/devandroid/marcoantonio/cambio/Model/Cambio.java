package devandroid.marcoantonio.cambio.Model;

public class Cambio {
}
